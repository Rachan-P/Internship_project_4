
 
   //Questions array
   let questions = [
     {
         
          question: "What does HTML stand for ?",
          answer : "Hypertext Markup Language",
          options : [
                           "Hypertensive Money Loan",
                           "Hypertext Manual Log",
                           "Hypertext Markup Language",
                           "Hypertech Math Link"
                         ]
     
     },
     {
      
          question: "Is HTML a programming language?",
          answer : "False",
          options : [
                           "True",
                           "False",
                           "Maybe",
                           "Not sure"  
                           ]
     
     },
    {
       
          question: "What does URL stand for ?",
          answer : "Uniform Resource Locator",
          options : [ 
                           "Universal Resource Language",
                           "Uniform Resource Locator",
                           "Universal Resource Locator",
                           "University Resource Link "
                           ]
     
     },
     {
     
          question: "What does HTTP stand for ?",
          answer : "Hypertext Transfer Protocol",
          options : [
                           "Hypertext Transmitter Protocol",
                           "Hypertest Transfer Protocol",
                           "Hypertech Transit Protocol",
                           "Hypertext Transfer Protocol"
                           ]
     }, 
     {
        
          question: "What does XML stand for ?",
          answer : "eXtensible Markup Language",
          options : [ 
                           "eXtended Markup Language",
                           "eXtensible Markup Language",
                           "eXtension Math Link",
                           "eXpensive Money Loan"
                        ]
     },
     {
         
          question: "What does API stand for ?",
          answer : "Application Programming Interface",
          options : [
                           "Application Programming Interface",
                           "Appliances Programming Interface",
                           "Application Programming Instruction",
                           "Appliances Programming Instruction"
                        ]
     },
     {
         
          question: "What does CSS stand for ?",
          answer : "Cascading Style Sheet",
          options : [
                           "Colorful Style Sheet",
                           "Cascading Sheet Style",
                           "Cascading Style Sheet",
                           "Creative Style Sheet"
                        ]
     },
      {
        
          question: "Is JavaScript a client-side scripting language?",
          answer : "True",
          options : [
                          "True",
                          "False",
                          "Maybe",
                          "Not sure"
                        ]
     },
     {
      
          question: "Is CSS used to define the structure and content of a webpage?",
          answer : "False",
          options : [
                          "True",
                          "False",
                          "Maybe",
                          "Not sure"
                        ]
     },
     {
    
      question: "What does SQL stand for ?",
      answer : "Structured Query Language",
      options : [
                      "Structured Query Language",
                      "System Query Language",
                      "Standard Query Language",
                      "Sequential Query Language"
                    ]
 }
      ];    
 
      function shuffleArray(array) {
           for (let i = array.length - 1; i > 0; i--) {
             const j = Math.floor(Math.random() * (i + 1));
             [array[i], array[j]] = [array[j], array[i]];
           }
         }
         
         // Shuffle the questions array
         shuffleArray(questions);
         const questionContainer = document.getElementById('question-container'); // Replace 'question-container' with the actual element ID

